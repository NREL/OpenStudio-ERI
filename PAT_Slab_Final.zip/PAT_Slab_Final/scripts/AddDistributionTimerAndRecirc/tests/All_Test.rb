
require "#{File.dirname(__FILE__)}/InternalGains_Test"
require "#{File.dirname(__FILE__)}/Recirculation_Test"
require "#{File.dirname(__FILE__)}/AddWateruseEquipmentObject_Test"
require "#{File.dirname(__FILE__)}/SiteWaterMainsTemperature_Test"
require "#{File.dirname(__FILE__)}/ScheduleDraws_Test"