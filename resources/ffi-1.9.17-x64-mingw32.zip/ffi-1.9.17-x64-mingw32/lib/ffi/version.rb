module FFI
  VERSION = '1.9.17'
end

